window.addEventListener('DOMContentLoaded', (event) => {
      // clear localStorage on page load
      localStorage.removeItem('quizTimeRemaining');
      localStorage.removeItem('quizAnswers');

});